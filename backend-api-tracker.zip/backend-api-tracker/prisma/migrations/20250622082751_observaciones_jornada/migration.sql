-- AlterTable
ALTER TABLE "Jornada" ADD COLUMN     "observaciones" TEXT;
